package org.acumen.training.codes;

public class InvalidStringException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidStringException(String message) {
        super(message);
    }
}